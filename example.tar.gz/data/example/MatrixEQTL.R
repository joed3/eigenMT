#!/usr/bin Rscript

# R script to run Matrix eQTL
# Originally written by Eric Hu with modifications by Mauro Pala and Joe Davis
require(optparse)

#---------------- FUNCTIONS

runMatrixEQTL = function(SNP_file_name,
  expression_file_name, 
  snps_location_file_name, 
  gene_location_file_name,
  covariates_file_name, 
  output_file_name_cis,
#  output_file_name_tra,
  cisDist,
  matrixEQTLuseANOVA = TRUE,
  pValueThreshold){
  
  # import MatrixEQTL library
  require('MatrixEQTL')
  
  # set model
  if(matrixEQTLuseANOVA == TRUE){
    
    useModel=modelANOVA
  }
  else{
    useModel=modelLINEAR
  }

  # Only associations significant at this level will be saved
  pvOutputThreshold_cis = pValueThreshold;
  pvOutputThreshold_tra = pValueThreshold;
  
  # Error covariance matrix
  # Set to numeric() for identity.
  errorCovariance = numeric();
    
  ## Load genotype data
  
  snps = SlicedData$new();
  snps$fileDelimiter = "\t"; # tab
  snps$fileOmitCharacters = "NA"; # denote missing values;
  snps$fileSkipRows = 1; # one row of column labels
  snps$fileSkipColumns = 1; # one column of row labels
  snps$fileSliceSize = 2000; # read file in pieces of 2,000 rows
  snps$LoadFile(SNP_file_name);
  
  ## Load gene expression data
  
  gene = SlicedData$new();
  gene$fileDelimiter = "\t"; # tab
  gene$fileOmitCharacters = "NA"; # denote missing values;
  gene$fileSkipRows = 1; # one row of column labels
  gene$fileSkipColumns = 1; # one column of row labels
  gene$fileSliceSize = 2000; # read file in pieces of 2,000 rows
  gene$LoadFile(expression_file_name);
  
  ## Load covariates
  
  cvrt = SlicedData$new();
  cvrt$fileDelimiter = "\t"; # the TAB character
  cvrt$fileOmitCharacters = "NA"; # denote missing values;
  cvrt$fileSkipRows = 1; # one row of column labels
  cvrt$fileSkipColumns = 1; # one column of row labels
  cvrt$fileSliceSize = 2000; # read file in one piece
  if(!is.null(covariates_file_name)) {
    cvrt$LoadFile(covariates_file_name);
  }
  
  ## Run the analysis
  snpspos = read.table(snps_location_file_name, header = TRUE, stringsAsFactors = FALSE);
  genepos = read.table(gene_location_file_name, header = TRUE, stringsAsFactors = FALSE);
  
  me = Matrix_eQTL_main(
    snps = snps, 
    gene = gene, 
    cvrt = cvrt,
    output_file_name = NULL,
    pvOutputThreshold = 0,
    useModel = useModel, 
    errorCovariance = errorCovariance, 
    verbose = FALSE, 
    output_file_name.cis = output_file_name_cis,
    pvOutputThreshold.cis = pvOutputThreshold_cis,
    snpspos = snpspos, 
    genepos = genepos,
    cisDist = cisDist,
    pvalue.hist = "qqplot");
  
}

#------------- MAIN

option_list <- list( 
  make_option(c("--SNP"), action="store", default='none',help="genotype matrix file name",type="character"),
  make_option(c("--GE"), action="store", default='none',help="gene expression matrix file name",type="character"),
  make_option(c("--snploc"), action="store", default='none',help="filename map of variant IDs to positions",type="character"),
  make_option(c("--OutputFilePath"), action="store", default='none',help="output file name for cis-eQTL results",type="character"),
  #make_option(c("--transOutputFilePath"), action="store", default='none',help="output filename for trans-eQTL results",type="character"),
  make_option(c("--geneloc"), action="store", default='none',help="filename for map of gene IDs to positions",type="character"),
  make_option(c("--cisDist"), action="store", default=1e6, help="maximum distance for cis-QTL. default 1e6",type='double'),
  make_option(c("--ANOVA"), action="store", default=TRUE, 
              help="Enter TRUE (default) if Matrix eQTL should use an ANOVA model to test for eQTLs. Enter FALSE if Matrix eQTL should use a linear model",
              type="logical"),
  make_option(c("--pValue"), action="store",default=1e-5, 
              help = "p-value threshold for eQTL discovery. Default is 1e-5. Enter 1 to report p-values for all variant-gene tests."), 
  make_option(c("--COV"), action="store", default = NULL, help="covariates file name",type="character")
)

opt = parse_args(OptionParser(option_list = option_list))

print('Command line arguments')
print(opt)

runMatrixEQTL(opt$SNP,
  opt$GE, 
  opt$snploc, 
  opt$geneloc,
  opt$COV, 
  opt$OutputFilePath,
  #opt$transOutputFilePath,
  opt$cisDist,
  opt$ANOVA,
  opt$pValue)




