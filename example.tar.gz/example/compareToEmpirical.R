## R script for comparing eigenMT example results to empirical p-values
## Authors: Joe Davis and Laure Fresard
## Date: 6/16/15

## Read in eigenMT example results
eigenMT = read.table('exampleOut.txt', header = T, stringsAsFactors = F)

## Read in empirical p-values
empirical = read.table('empiricalPvalues.txt', header = T, stringsAsFactors = F)

## Restrict to genes in the example output
genes = unique(eigenMT$gene)
empirical = empirical[empirical$GENE %in% genes, ]

##Sort by gene ID
eigenMT = eigenMT[order(eigenMT$gene), ]
empirical = empirical[order(empirical$GENE), ]

##Plot relationship between empirical and eigenMT estimates
pdf('pvalueComparison.pdf')

plot(empirical$EMPIRICAL_PVALUE, eigenMT$BF, 
	col = 'dodgerblue', pch = 16, xlab = 'Empirical P-value', ylab = 'eigenMT P-value', main = 'Comparison of eigenMT to Empirical P-values')
abline(a = 0, b = 1)

plot(-log10(empirical$EMPIRICAL_PVALUE), -log10(eigenMT$BF), 
	col = 'dodgerblue', pch = 16, xlab = 'Empirical P-value (-log10)', ylab = 'eigenMT P-value (-log10)', main = 'Comparison of eigenMT to Empirical P-values')
abline(a = 0, b = 1)

plot(-log10(empirical$EMPIRICAL_PVALUE[empirical$EMPIRICAL_PVALUE > 1e-4]), -log10(eigenMT$BF[empirical$EMPIRICAL_PVALUE > 1e-4]), 
	col = 'dodgerblue', pch = 16, xlab = 'Empirical P-value (-log10)', ylab = 'eigenMT P-value (-log10)', main = 'Comparison of eigenMT to Empirical P-values')
abline(a = 0, b = 1)

dev.off()

